
public class Homework5 {

	public static void main(String[] args) {
		   int i; int sum = 0;
		for(i=1;i<=100;i++){
			int b=i%10;
			if(b!=3){
				sum=sum+i;
			}
			
		}
		System.out.println(sum);
		
		
	}
	
}
