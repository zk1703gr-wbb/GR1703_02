
public class TestPhone {
	
	public static void main(String[] args) {
		
		 Phone a = new Phone();
	     a.paizi="С��";
	     a.price=1599 ;
	     a.system="andiord";
	     a.screen=5.15;      
	     a.shouji();
	     
		
		
	}

}
