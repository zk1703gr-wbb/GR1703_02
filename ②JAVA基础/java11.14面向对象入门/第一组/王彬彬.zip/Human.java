
public class Human {

	public String name;
	  public int age;
	  public double height;
	  public String address;
	  public void information(){
		   System.out.println("�ҵ�������"+name+"�����ߣ�"+height+"��ַ�� ��"+address);
		   System.out.print("ϲ���Ե�ʳ���ǣ�");
	  }
	 
	  public void eat(String a,String b){
	          if(a.equals("/t"+"����")){
	             System.out.println(a);
	          }else {
	              System.out.println(b);
	              }
	          } 
	  public int sleep(int m,int n ){
	                    if(m<n){
	                     return m;
	                    }else{ 
	                      return n;
	                     } 	
               }
	
	  
}
