import java.util.Scanner;


public class Homework4 {

	public static void main(String[] args) {
		
		int i;
		for(i=2;i<1000;i++){
		int bai=i/100;
		int a=bai*bai*bai;
		int shi=i/10%10;
		int b=shi*shi*shi;
		int ge=i%10;
		int c=ge*ge*ge;
		if(a+b+c==i){
		    System.out.println(i);
		   }
		}
		
		
		
	}
	
}
