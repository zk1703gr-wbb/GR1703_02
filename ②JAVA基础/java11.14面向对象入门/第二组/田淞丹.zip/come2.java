import come.dome;


public class come2 {
	public static void main(String[] args) {
		come c=null;
		c=new come();
		come b=new come();
		b.name ="����";
		b.nl=19;
		b.sg=180;
		b.dz="�ܿ���";
		b.cf="�緹";
		b.sj="˯��";
		b.info();
		b.xhc();
		
		
	}

}
