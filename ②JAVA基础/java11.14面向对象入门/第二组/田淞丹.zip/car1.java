
public class car1 {
	public static void main(String[] args) {
		car c=null;
		c= new car();
		car b=new car ();
		b.dog="�ȳ�";
		b.getou="�е�";
		b.pinzhong="��ë";
		b.nl="1";
		b.run();
		b.ah();
	}

}
