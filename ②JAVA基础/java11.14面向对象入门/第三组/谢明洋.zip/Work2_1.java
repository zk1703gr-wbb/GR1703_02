
public class Work2_1 {
	public static void main(String[] args) {
		
		Work2 W=new Work2();
		 String food="wine";
		 int i=8;
		
		W.adress="������";
		W.age=61;
		W.height=168;
		W.name="���";
		
		W.person();
		W.eat(food);
		W.sleep(i);
		
	
	}

}
