
public class Work1_1 {
	public static void main(String[] args) {
		
		Work1 W=new Work1();
		
		W.address="��Ԫ���";
		W.build=1976;
		W.people=8000;
		W.School="�ܿ�ְҵ����ѧԺ";
		
		W.MySchool();
				
	}
	
	

}
