package zuoye1114;

public class zuoye1 {
	public String sheng;
	public String shi;
	public String xian;
	public void zhuzhi(){
		System.out.println("�ҵ�סַΪ��"+sheng+","+shi+","+xian+"��");
	}
}
