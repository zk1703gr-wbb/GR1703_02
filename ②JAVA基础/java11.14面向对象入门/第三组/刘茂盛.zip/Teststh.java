
public class Teststh {
	public static void main(String[] args) {
		sth b=new sth();
		b.ban=3;
		b.classmate=22;
		b.computer=24;
		b.deng=8;
		b.zhuozi=24;
		b.jieshao();
	}

}
